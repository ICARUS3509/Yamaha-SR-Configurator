
// Exemple de logique JS simple à améliorer
document.querySelector("#reservoir").onclick = () => {
    alert("Tu peux imaginer ici un menu de choix du réservoir !");
};
